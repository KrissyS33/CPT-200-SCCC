import React from 'react';
import Contact from './components/Contact'
import About from './components/About'
import Resources from './components/Resources'
import Submit from './components/Submit';
import Checkbox from './components/Checkbox';
import CalendarRange from './components/CalenderRange';
import Body from './components/Body';
import Header from './components/Header';
import Daterange from './components/Daterange';

function App() {
  return (
    <div>    
    <Header />
    <Checkbox />
    <Daterange />
    <CalendarRange />
    <Submit />
    <Body />
    <Resources />
    <About />
    <Contact />
    </div>
  );
}

export default App;
