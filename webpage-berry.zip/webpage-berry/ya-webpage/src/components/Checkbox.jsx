import React from 'react'



const Checkbox = () => {
  return (
    
    <form>
      <div className='bg-white w-auto h-auto pb-10 mt-16 mx-5 rounded-lg'>
          
            <p className='font-bold text-center text-4xl'>Select What You Want to Track </p>

            <div className=''>

                <div className='mt-10 mx-10 space-y-6'>
                    <div className='flex space-x-4 items-center'>
                        <input type='checkbox' className='w-15 h-15'/> <p>Views</p>
                    </div>
                    <div className='flex space-x-4 items-center'>
                        <input type='checkbox' className='w-15 h-15'/> <p>Comments</p>
                    </div>
                    <div className='flex space-x-4 items-center'>
                        <input type='checkbox' className='w-15 h-15'/> <p>Likes</p>
                    </div>
                    <div className='flex space-x-4 items-center'>
                        <input type='checkbox' className='w-15 h-15'/> <p>Dislikes</p>
                    </div>
                    <div className='flex space-x-4 items-center'>
                        <input type='checkbox' className='w-15 h-15'/> <p>Estimated Minutes Watched</p>
                    </div>
                    <div className='flex space-x-4 items-center'>
                        <input type='checkbox' className='w-15 h-15'/> <p>Average View Duration</p>
                    </div>
                </div>

              </div>
      </div>
      
    </form>

    
  )
}

export default Checkbox