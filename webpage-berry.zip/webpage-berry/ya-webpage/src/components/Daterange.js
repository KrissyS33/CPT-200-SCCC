import React from 'react'

const Daterange = () => {
  return (
    <div className='bg-white w-auto h-auto pb-10 mt-16 mx-5 rounded-lg'>
        <p className='font-bold text-center text-4xl'>Select The Date Range </p>
    </div>
  )
}

export default Daterange