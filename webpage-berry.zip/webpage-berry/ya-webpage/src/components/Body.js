import React, { Component } from 'react'


class Body extends Component {
    render(){
        return(
            <div className="max-w-full container mx-auto my-12">
                
                

            </div>
        )

    }
}

export default Body