import React from 'react'

const Resources = () => {
  return (
    <div className =' w-full bg-white py-16 px-4'>
        <div className='max-w-[1240px] mx-auto grid md:grid-cols-2'>
            <div className='flex flex-col justify-center'>
                <p className='text-4xl'>Resources</p>
                <ul>
                    <li className='text-2xl'>Front End</li>
                    <li>Node JS</li>
                    <li>React</li>
                    <li>Tailwind CSS</li>
                    <li className='text-2xl'>Back End</li>
                    <li>Django</li>
                    <li>Python</li>
                    <li></li> 

                </ul>
                

            </div>

        </div>
    </div>

  )
}

export default Resources