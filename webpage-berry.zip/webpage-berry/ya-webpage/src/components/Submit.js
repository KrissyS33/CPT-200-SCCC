import React from 'react'

const Submit = () => {
  return (
    <div >
        <button class='group h-10 pl-5 rounded-full flex items-center space-x-4 bg-red-800'>
            <span class='text-sm text-white text-center'>Submit</span>
            <div class='flex items-center'></div>

        </button>

    </div>
  )
}

export default Submit