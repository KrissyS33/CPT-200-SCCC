import React from 'react'

const Contact = () => {
  return (
    <div className =' w-full bg-white py-16 px-4'>
        <div className=''>
            
            <div className='flex flex-col justify-center'>
                <p className='text-4xl'>Contact</p>
                <h1 className='pt-4'>kmartconsultingllc@gmail.com</h1>
            </div>

        </div>
    </div>
  )
}

export default Contact